#Author: Mike Jacobi
#Virtual Mafia Game
#Instructors: Roya Ensafi, Jed Crandall
#Cybersecurity, Spring 2012
#This script has generic helper functions used by the Mafia server and clients

import os
import time
import threading
from threading import Thread

pipeRoot='/home/moderator/pipes/'

handle=''

conns=[]
allowed=[]

def obscure():
    while 1:
	os.system('ls '+pipeRoot+'* > /dev/null 2> /dev/null')
	time.sleep(.1)

def allow(pipes):
    global allowed
    allowed=pipes

def handleConnections(timeTillStart):
    possibleConnections=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    for c in possibleConnections:
        t=Thread(target=connect,args=[str(c)+'tos'])
        t.start()
    time.sleep(timeTillStart)
    return conns

def connect(inputPipe):
    input=''
    while input!='connect':
        try:
            input=recv(inputPipe)[2]
        except:
            pass
        if input=='connect':
            log(str(inputPipe)+' connected',1)
	    try:
		out='sto'+str(int(inputPipe[0]+inputPipe[1]))
	    except:
		out='sto'+inputPipe[0]
            send('Connected',out)
            conns.append(inputPipe)


def broadcast(msg, pipes):
    #log stuff here
    for pipe in pipes:
	try:
	    pipe='sto'+str(int(pipe[0]+pipe[1]))
	except:
        	pipe = 'sto'+pipe[0]
        try:
            send(msg,pipe)
        except Exception, p:
            log('broadcast error:'+str(p),1)
            

def send(msg, pipe):
    global allowed

    msg=msg.replace("'",'').replace('"','')

    try:
	try:
	    moniker=str(int(pipe[0]+pipe[1]))
	except:
       	    moniker=pipe[0]
        try:
            msg=msg.strip('\n')
        except:
            pass
        
        os.popen('echo "" > '+pipeRoot+pipe+'D/'+pipe).close()
        msg='(echo :'+moniker+':'+msg+' > '+pipeRoot+pipe+'D/'+pipe+') 2> /dev/null'
        o=os.popen(msg)
        o.read()
        o.close()
    except Exception, p:
        log('send error:'+str(p),1)

def recv(pipe):
    output=''
    while output=='':
        try:
            msg='(cat '+pipeRoot+str(pipe)+'D/'+str(pipe)+') 2> /dev/null'
            f=os.popen(msg)
            output=f.read().split('\n')
            f.close()

            for i in range(len(output)):
                if len(output[i])>0:
                    output[i]=output[i].split(':')
                    return output[i] 
        except Exception, p:
            log('receive error:'+str(p),1)


def log(msg, printBool):
    global handle
    handle.write(msg+'\n')
    if printBool:
        print msg
def setLogHandle(fileHandle):
    global handle
    handle=fileHandle

def clear(pipes):
    for p in pipes:
        for i in range(10):
            t=Thread(target=recv,args=[p])
            t.start()

def multiRecv(pipe, pipes,endTime):
    global allowed
    start = time.time()
    while 1:
        if pipe in allowed:
            msg=recv(pipe)
        else:
            time.sleep(1)
            continue

        if msg!=None:
            broadcast(msg[1]+'-'+msg[2], modPipes(pipe,allowed))

def groupChat(pipes, endTime):
    for pipe in pipes:
        newPipes=modPipes(pipe, pipes)
        t = Thread(target=multiRecv,args=[pipe, newPipes, endTime])
        t.start()
        
#remove one pipe from pipes
def modPipes(pipe, pipes):
    newPipes=[]
    for p in pipes:
        if p!=pipe:
            newPipes.append(p)
    return newPipes

#this is a dictionary of booleans that forces only one group to vote at a time.
voteAllowDict={'w':0,'W':0,'t':0}
votes={}
def poll(pipes, votetime, validTargets, w):
    global votes,voteAllowDict,allowed
    allowed=[]
    broadcast('Time to vote.  Valid votes are '+str(validTargets), pipes)


    voteAllowDict={'w':0,'W':0,'t':0}
    voteAllowDict[w]=1

    voteThreads=[]
    votes={}
    for pipe in pipes:
        t = Thread(target=vote,args=[pipe, pipes, validTargets, w])
        voteThreads.append(t)
        voteThreads[-1].start()
    time.sleep(votetime+1)
    log(str(votes),1)

    winner=[]
    mode=0
    for v in votes.keys():
        if votes[v]>mode:
            mode=votes[v]
            winner=[v]
        elif votes[v]==mode:
            winner.append(v)
    return winner

def vote(pipe, pipes, validTargets, w):#w is a bool for 'is witch vote'
    global votes,voteAllowDict

    try:
	client='sto'+str(int(pipe[0]+pipe[1]))
    except:
        client='sto'+pipe[0]
    while voteAllowDict[w]:
        i=recv(pipe)

        try:
            str(i[2])
        except Exception, p:
            continue 
        if voteAllowDict[w]==0:
            break
        try:
             if i[2] in validTargets:
                try:
                    votes[i[2]]+=1
                except Exception, p:
                    votes[i[2]]=1

                if w=='W':#capitol W is for 'witch'.  
                    send('vote received', client)
                else:
                    broadcast(client+' voted for '+str(i[2]), pipes)
                break
             else:
                send('invalid vote:'+str(i[2]),client)   
        except:
            pass

def spawnDeathSpeech(pipe,all,endtime):
    t=Thread(target=deathSpeech,args=[pipe,all])
    t.start()
    time.sleep(endtime)
    t._Thread__stop()
    del(threading._active[t.ident])


def deathSpeech(pipe, all):
    newPipes=modPipes(pipe,all)
    while 1:
        i=recv(pipe)
        try:
            broadcast(pipe+'-'+i[2],newPipes)
        except:
            pass

