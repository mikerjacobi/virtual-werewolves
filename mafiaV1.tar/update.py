import os

for i in range(1,16):
	os.system('./update.sh '+str(i))
